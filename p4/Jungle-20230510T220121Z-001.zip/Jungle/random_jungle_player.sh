#!/bin/bash

python3 jungle_random.py
