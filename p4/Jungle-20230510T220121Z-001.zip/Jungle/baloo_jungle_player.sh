#!/bin/bash

python3 baloo.py
